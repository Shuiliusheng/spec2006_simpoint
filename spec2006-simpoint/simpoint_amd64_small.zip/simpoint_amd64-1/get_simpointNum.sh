# !/bin/bash

top_dir=./
for dir in `ls`
do
	if [ -d $dir ]; then
		cd $dir
		for sub_dir in `ls`
		do
			cd $sub_dir
			simpoint_num=0
			if [ -e "simpoint_file" ]; then
				simpoint_num=`wc -l simpoint_file`
				echo $dir"  : "$sub_dir"  :  "$simpoint_num
			else
				echo $dir"  : "$sub_dir"  :  ""simpoint_file is not created!"
			fi
			cd ..
		done
		cd ..
	fi
done
