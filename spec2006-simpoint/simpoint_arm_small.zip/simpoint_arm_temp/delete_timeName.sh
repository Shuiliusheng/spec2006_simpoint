#!/bin/bash

ARGC=$# #
if [[ "$ARGC" == 0 ]]; then # Bad number of arguments.
    echo "*.sh dir_name"
    exit
fi

function delay_last_time_char(){
	top_dir=$1
	if [ -d $top_dir ]; then
		cd $top_dir
		#delay last 14 chars in string
		for name in `ls`
		do
			if [ -d $name ]; then
				#dis=`expr ${#name} - 14`
				#dst_name=${name:0:$dis}
				#echo "mv $name to $dst_name"
				#echo "${name:$dis:${#name}}" >$name/createTime
				#mv $name $dst_name
				echo "rm $name/run"
				rm $name/simpoint.bb.gz
			fi
		done
		cd -
	fi
}

top_dir=$1
cd $top_dir
for sub_dir in `ls`
do
        if [ -d $sub_dir ]; then
                echo $sub_dir
                delay_last_time_char $sub_dir
        fi
done
