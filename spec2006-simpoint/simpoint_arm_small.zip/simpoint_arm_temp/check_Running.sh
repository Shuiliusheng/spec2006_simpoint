# !/bin/bash

ARGC=$# #
if [[ "$ARGC" == 0 ]]; then # Bad number of arguments.
    echo "*.sh dir_name"
    exit
fi

function isRunning()
{
	dir=$1
	str=$@
	for n in `ps -ef | grep $1 |wc`
	do
		if [ "$n" -eq "1" ];then
			echo $str" -----  Not Running!"
		else
			echo $str" -----  Is  Running!"
		fi
		break
	done
}

function check_checkpointNum(){
	top_dir=$1
	if [ -d $top_dir ]; then
		cd $top_dir
		#delay last 14 chars in string
		for name in `ls`
		do
			if [ -d $name ]; then
				isRunning $name 
			fi
		done
		cd -
	fi
}
top_dir=$1
cd $top_dir
for sub_dir in `ls`
do
       if [ -d $sub_dir ]; then
               check_checkpointNum $sub_dir
       fi  
done

