# !/bin/bash
simpoint_dir=/home/chw/SimPoint.3.2
simpoint_file=simpoint_file
weight_file=weight_file

/home/chw/SimPoint.3.2/bin/simpoint -loadFVFile simpoint.bb.gz -dim 50 -maxK 30 -saveSimpoints $simpoint_file -saveSimpointWeights $weight_file -inputVectorsGzipped
